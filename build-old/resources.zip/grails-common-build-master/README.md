# Grails Common Build Scripts

Common Gradle Build Scripts for Publishing Grails Core Projects

Consumers of these scripts should create valid `build.gradle` and `gradle.properties` files.

See https://github.com/grails/grails-async for an example of a build that uses these scripts.
